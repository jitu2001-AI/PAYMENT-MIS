import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

class AppDb {
  AppDb._();
  static final AppDb instance = AppDb._();
  Database? _db;
  Future<Database> get db async => _db ??= await _open();

  Future<Database> _open() async {
    final base = await getDatabasesPath();
    return openDatabase(p.join(base, 'payment_mis.db'), version: 1,
      onConfigure: (d) async => d.execute('PRAGMA foreign_keys = ON'),
      onCreate: (d, version) async {
        await d.execute('''CREATE TABLE clients(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, phone TEXT NOT NULL, business_name TEXT DEFAULT '', language TEXT NOT NULL DEFAULT 'English', notes TEXT DEFAULT '', created_at TEXT NOT NULL, updated_at TEXT NOT NULL)''');
        await d.execute('''CREATE TABLE invoices(id INTEGER PRIMARY KEY AUTOINCREMENT, client_id INTEGER NOT NULL, invoice_no TEXT DEFAULT '', invoice_date TEXT NOT NULL, due_date TEXT NOT NULL, original_minor INTEGER NOT NULL, paid_minor INTEGER NOT NULL DEFAULT 0, grace_days INTEGER NOT NULL DEFAULT 0, is_paid INTEGER NOT NULL DEFAULT 0, date_marked_paid TEXT, notes TEXT DEFAULT '', created_at TEXT NOT NULL, FOREIGN KEY(client_id) REFERENCES clients(id) ON DELETE CASCADE)''');
        await d.execute('''CREATE TABLE payments(id INTEGER PRIMARY KEY AUTOINCREMENT, invoice_id INTEGER NOT NULL, amount_minor INTEGER NOT NULL, paid_at TEXT NOT NULL, notes TEXT DEFAULT '', FOREIGN KEY(invoice_id) REFERENCES invoices(id) ON DELETE CASCADE)''');
        await d.execute('''CREATE TABLE message_templates(id INTEGER PRIMARY KEY AUTOINCREMENT, language TEXT NOT NULL, type TEXT NOT NULL, body TEXT NOT NULL, UNIQUE(language,type))''');
        await d.execute('''CREATE TABLE reminder_history(id INTEGER PRIMARY KEY AUTOINCREMENT, client_id INTEGER NOT NULL, invoice_id INTEGER, type TEXT NOT NULL, language TEXT NOT NULL, prepared_at TEXT NOT NULL, amount_minor INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'Prepared', message TEXT NOT NULL, FOREIGN KEY(client_id) REFERENCES clients(id) ON DELETE CASCADE, FOREIGN KEY(invoice_id) REFERENCES invoices(id) ON DELETE SET NULL)''');
        await d.execute('''CREATE TABLE app_settings(key TEXT PRIMARY KEY, value TEXT NOT NULL)''');
        final templates = <Map<String, String>>[
          {'language':'English','type':'Initial','body':'Hello {Client_Name},\n\nThis is a friendly reminder that your payment of {Amount} was due on {Due_Date}.\n\nPlease let us know when we can expect payment.\n\nThank you for your cooperation.\n{Business_Name}'},
          {'language':'English','type':'Follow-up','body':'Hello {Client_Name},\n\nOur records indicate that your payment of {Amount} has been overdue for {Days_Overdue} days, with a due date of {Due_Date}.\n\nKindly arrange payment at your earliest convenience. If you have already paid, please disregard this reminder and share the payment confirmation.\n\nThank you.\n{Business_Name}'},
          {'language':'English','type':'Final','body':'Hello {Client_Name},\n\nThis is a final follow-up regarding the outstanding payment of {Amount}, due on {Due_Date} and overdue by {Days_Overdue} days. Please contact us to confirm your payment timeline. If already paid, kindly share confirmation.\n\nThank you.\n{Business_Name}'},
          {'language':'Hindi','type':'Initial','body':'नमस्ते {Client_Name},\n\nआपको सूचित करना है कि {Due_Date} को देय {Amount} का भुगतान अभी हमारे रिकॉर्ड में बकाया दिखाई दे रहा है।\n\nकृपया भुगतान की स्थिति बताने का कष्ट करें। यदि आप भुगतान पहले ही कर चुके हैं, तो कृपया इस संदेश को अनदेखा करें।\n\nधन्यवाद।\n{Business_Name}'},
          {'language':'Hindi','type':'Follow-up','body':'नमस्ते {Client_Name},\n\nहमारे रिकॉर्ड के अनुसार {Due_Date} को देय {Amount} का भुगतान {Days_Overdue} दिनों से बकाया है। कृपया सुविधानुसार जल्द भुगतान करें। यदि भुगतान हो चुका है, तो कृपया पुष्टि साझा करें।\n\nधन्यवाद।\n{Business_Name}'},
          {'language':'Hindi','type':'Final','body':'नमस्ते {Client_Name},\n\n{Due_Date} को देय {Amount} के भुगतान के लिए यह अंतिम विनम्र अनुस्मारक है। भुगतान {Days_Overdue} दिनों से बकाया है। कृपया भुगतान की स्थिति बताएं। यदि भुगतान हो चुका है, तो कृपया पुष्टि साझा करें।\n\nधन्यवाद।\n{Business_Name}'},
          {'language':'Spanish','type':'Initial','body':'Hola {Client_Name},\n\nEste es un amable recordatorio de que su pago de {Amount} vencía el {Due_Date}.\n\nPor favor, indíquenos cuándo podemos esperar el pago.\n\nGracias por su colaboración.\n{Business_Name}'},
          {'language':'Spanish','type':'Follow-up','body':'Hola {Client_Name},\n\nNuestros registros indican que su pago de {Amount}, con vencimiento el {Due_Date}, lleva {Days_Overdue} días de retraso. Le rogamos que lo gestione a la mayor brevedad. Si ya pagó, ignore este mensaje y comparta el comprobante.\n\nGracias.\n{Business_Name}'},
          {'language':'Spanish','type':'Final','body':'Hola {Client_Name},\n\nEste es un último recordatorio sobre el pago pendiente de {Amount}, con vencimiento el {Due_Date} y {Days_Overdue} días de retraso. Por favor, confirme la fecha de pago. Si ya pagó, comparta el comprobante.\n\nGracias.\n{Business_Name}'}
        ];
        for (final t in templates) { await d.insert('message_templates', t); }
        for (final entry in {'business_name':'My Business','currency':'INR','default_grace':'0','initial_threshold':'1','followup_threshold':'7','final_threshold':'15','default_country_code':'91'}.entries) {
          await d.insert('app_settings', {'key': entry.key, 'value': entry.value});
        }
      });
  }
}
