class PaymentLogic {
  static int daysOverdue({required DateTime dueDate, required int graceDays, required DateTime today, required bool paid}) {
    if (paid) return 0;
    final due = DateTime(dueDate.year, dueDate.month, dueDate.day);
    final now = DateTime(today.year, today.month, today.day);
    final overdueStart = due.add(Duration(days: graceDays < 0 ? 0 : graceDays));
    if (!now.isAfter(overdueStart)) return 0;
    return now.difference(overdueStart).inDays;
  }

  static String ageingBucket(int days) {
    if (days <= 0) return 'Not yet due';
    if (days <= 7) return '1–7 days';
    if (days <= 15) return '8–15 days';
    if (days <= 30) return '16–30 days';
    return 'More than 30 days';
  }

  static int balanceMinor(int originalMinor, int paidMinor) => (originalMinor - paidMinor).clamp(0, originalMinor).toInt();

  static String fillTemplate(String template, Map<String, String> values) {
    var result = template;
    values.forEach((key, value) => result = result.replaceAll('{$key}', value));
    return result;
  }
}
