import 'package:flutter_test/flutter_test.dart';
import 'package:payment_mis/services/payment_logic.dart';

void main() {
  group('PaymentLogic', () {
    test('grace period ends inclusively and counts calendar days', () {
      expect(PaymentLogic.daysOverdue(dueDate: DateTime(2026,10,1), graceDays: 3, today: DateTime(2026,10,4,23), paid: false), 0);
      expect(PaymentLogic.daysOverdue(dueDate: DateTime(2026,10,1), graceDays: 3, today: DateTime(2026,10,5), paid: false), 1);
    });
    test('paid invoice is never overdue', () {
      expect(PaymentLogic.daysOverdue(dueDate: DateTime(2020,1,1), graceDays: 0, today: DateTime(2026,10,10), paid: true), 0);
    });
    test('balance never becomes negative', () {
      expect(PaymentLogic.balanceMinor(10000, 3000), 7000);
      expect(PaymentLogic.balanceMinor(10000, 12000), 0);
    });
    test('ageing buckets boundaries', () {
      expect(PaymentLogic.ageingBucket(0), 'Not yet due');
      expect(PaymentLogic.ageingBucket(7), '1–7 days');
      expect(PaymentLogic.ageingBucket(8), '8–15 days');
      expect(PaymentLogic.ageingBucket(16), '16–30 days');
      expect(PaymentLogic.ageingBucket(31), 'More than 30 days');
    });
    test('template placeholders are substituted', () {
      expect(PaymentLogic.fillTemplate('Hi {Client_Name}: {Amount}', {'Client_Name':'Ravi','Amount':'₹200'}), 'Hi Ravi: ₹200');
    });
  });
}
