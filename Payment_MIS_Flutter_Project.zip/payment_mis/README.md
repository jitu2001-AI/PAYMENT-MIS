# Payment MIS — Flutter Android project

A local-first Flutter app for client records, invoice balances, overdue/grace-period calculations, editable English/Hindi/Spanish reminder templates, WhatsApp click-to-chat, reminder history, ageing reports and CSV export.

## Build requirements
- Flutter stable SDK (Dart SDK included; Flutter 3.24+ recommended)
- Android Studio with Android SDK Platform and Build Tools installed
- JDK 17

## Open and build
1. Extract this project folder.
2. Open the `payment_mis` folder in Android Studio, or run `flutter pub get` from this directory.
3. If Android Studio has not generated Flutter's local SDK mapping, run `flutter doctor` and ensure Android SDK licenses are accepted with `flutter doctor --android-licenses`.
4. Run `flutter analyze` and `flutter test`.
5. Connect an Android phone with USB debugging enabled or launch an emulator and run `flutter run`.
6. Build the release APK: `flutter build apk --release`.
7. APK output: `build/app/outputs/flutter-apk/app-release.apk`.

Application ID: `com.paymentmis.app`; displayed name: `Payment MIS`; minimum Android API: 23 (Android 6.0).

## Important behaviour
- All client, invoice, payment and reminder records are stored locally in SQLite. No backend is used and no financial data is uploaded by the app.
- Money is stored in integer minor units to avoid floating-point storage errors.
- Grace period is inclusive: due date + grace days is the last non-overdue calendar date; overdue starts the following day.
- WhatsApp is opened with a prefilled message. The user must press Send in WhatsApp. Opening WhatsApp is not proof of sending, delivery or reading.
- Uninstalling may remove local data. Use the CSV export regularly. CSV export is a reporting export, not a full restorable SQLite backup.

## Scope notes
The first version supports one invoice record per entry and cumulative paid amount editing; the schema includes a `payments` table for future transaction-level payment history. Partial payment balance calculation is supported. Official WhatsApp Business Platform sending, automatic background delivery, app lock, and full database backup/restore are not implemented. Do not treat CSV export as a full backup.

## Test coverage
Unit tests cover calendar-date overdue/grace logic, paid invoice exclusion, balance clamping, ageing boundaries and template substitution. Run them with `flutter test` on a machine with Flutter installed.
